# Student Grade Prediction

Predict student grades (pass/fail and approximate grade) from a small tabular dataset.

## Contents
- `data/generate_synthetic_data.py` — script to generate a synthetic CSV dataset (`students_raw.csv`).
- `src/preprocess.py` — preprocessing utilities.
- `src/train.py` — trains models (Logistic Regression and RandomForest) and saves best model to `models/`.
- `src/predict.py` — load a saved model and predict on a JSON input.
- `requirements.txt`

## Quick start
```bash
cd student-grade-prediction
python data/generate_synthetic_data.py    # creates data/students_raw.csv
pip install -r requirements.txt
python src/train.py
python src/predict.py --input sample_input.json
```
