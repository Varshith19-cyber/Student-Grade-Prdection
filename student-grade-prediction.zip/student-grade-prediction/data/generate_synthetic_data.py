import pandas as pd
import numpy as np
import os

os.makedirs('data', exist_ok=True)
np.random.seed(42)

N = 1000
attendance = np.clip(np.random.normal(80,10,size=N), 40,100).astype(int)
internal_marks = np.clip(np.random.normal(60,15,size=N), 0,100).astype(int)
assignments = np.clip(np.random.poisson(8, size=N), 0,10)
study_hours = np.clip(np.random.normal(5,2,size=N), 0,20)
# create a grade roughly based on internal_marks + attendance + study_hours
score = 0.5*internal_marks + 0.2*attendance + 5*study_hours + assignments*2 + np.random.normal(0,10,size=N)
# grades A/B/C/D based on score
grade = pd.cut(score, bins=[-1,60,75,90,999], labels=['D','C','B','A'])
pass_fail = (score >= 60).astype(int)

df = pd.DataFrame({
    'attendance_pct': attendance,
    'internal_marks': internal_marks,
    'assignments_completed': assignments,
    'study_hours_per_week': study_hours,
    'score': score.round(1),
    'grade': grade,
    'pass': pass_fail
})

df.to_csv('data/students_raw.csv', index=False)
print('Wrote data/students_raw.csv with', len(df), 'rows')
