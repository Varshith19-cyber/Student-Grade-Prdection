import joblib
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report
from preprocess import load_data, prepare_xy, train_test_split_xy
import os

os.makedirs('models', exist_ok=True)

def main():
    df = load_data()
    X,y = prepare_xy(df)
    X_train,X_test,y_train,y_test = train_test_split_xy(X,y)
    # Logistic Regression
    lr = LogisticRegression(max_iter=1000)
    lr.fit(X_train,y_train)
    y_pred_lr = lr.predict(X_test)
    print('Logistic Regression:')
    print(classification_report(y_test,y_pred_lr))
    # RandomForest
    rf = RandomForestClassifier(n_estimators=100, random_state=42)
    rf.fit(X_train,y_train)
    y_pred_rf = rf.predict(X_test)
    print('Random Forest:')
    print(classification_report(y_test,y_pred_rf))
    # save the rf model
    joblib.dump(rf, 'models/random_forest_student_pass.pkl')
    print('Saved model to models/random_forest_student_pass.pkl')

if __name__ == '__main__':
    main()
