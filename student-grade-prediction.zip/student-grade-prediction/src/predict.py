import joblib
import json
import argparse
import pandas as pd

def predict_from_json(model_path, input_json):
    model = joblib.load(model_path)
    x = pd.DataFrame([input_json])
    pred = model.predict(x)[0]
    prob = model.predict_proba(x)[0].max() if hasattr(model, 'predict_proba') else None
    return pred, prob

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--model', default='models/random_forest_student_pass.pkl')
    parser.add_argument('--input', default='sample_input.json')
    args = parser.parse_args()
    with open(args.input) as f:
        data = json.load(f)
    pred, prob = predict_from_json(args.model, data)
    print('Prediction (pass=1, fail=0):', pred)
    print('Confidence (if available):', prob)
